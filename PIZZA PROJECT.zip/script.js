// Select pizza base
const baseList = document.querySelector('.base-list');
const bases = document.querySelectorAll('.base');
let selectedBase;

bases.forEach(base => {
  base.addEventListener('click', () => {
    if (selectedBase) {
      selectedBase.classList.remove('selected');
    }
    base.classList.add('selected');
    selectedBase = base;

    // Show toppings list
    const toppingsList = document.querySelector('.toppings-list');
    toppingsList.style.display = 'block';
  });
});

// Drag and drop toppings onto pizza
const pizzaImage = document.querySelector('#pizza-image');
const droppableArea = document.querySelector('#droppable-area');
const toppings = document.querySelectorAll('.topping');
let selectedToppings = [];

toppings.forEach(topping => {
  topping.addEventListener('dragstart', () => {
    topping.classList.add('dragging');
  });

  topping.addEventListener('dragend', () => {
    topping.classList.remove('dragging');
  });

  topping.addEventListener('click', () => {
    if (selectedToppings.includes(topping.dataset.topping)) {
      selectedToppings = selectedToppings.filter(item => item !== topping.dataset.topping);
      topping.classList.remove('selected');
    } else {
      selectedToppings.push(topping.dataset.topping);
      topping.classList.add('selected');
    }

    // Update pizza image
    const toppingsString = selectedToppings.join('-');
    pizzaImage.src = `pizza-${selectedBase.dataset.base}-${toppingsString}.jpg`;
  });
});

droppableArea.addEventListener('dragover', e => {
  e.preventDefault();
});

droppableArea.addEventListener('drop', e => {
  e.preventDefault();

  const topping = document.querySelector('.dragging');
  if (topping) {
    selectedToppings.push(topping.dataset.topping);
    topping.classList.remove('dragging');
    topping.classList.add('selected');

    // Update pizza image
    const toppingsString = selectedToppings.join('-');
    pizzaImage.src = `pizza-${selectedBase.dataset.base}-${toppingsString}.jpg`;
  }
});
